import React, { useState } from 'react';
import {
  Box,
  Button,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  Checkbox,
  FormGroup,
} from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';

export const ObjectDetection = () => {
  const [open, setOpen] = useState(false);
  const [selectedDetections, setSelectedDetections] = useState({
    recording: false,
    snapshot: false,
    anpr: false,
    person: false,
    bike: false,
    animal: false,
    fire: false,
    smoke: false,
    umbrella: false,
    briefcase: false,
    mask: false,
    garbage: false,
    weapon: false,
    wrongdirection: false,
    queue: false,
  });

  const handleIconClick = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleCheckboxChange = (event) => {
    setSelectedDetections(prevState => ({
      ...prevState,
      [event.target.name]: event.target.checked,
    }));
  };

  const handleSave = async () => {
    console.log('Selected Detections:', selectedDetections);
    setOpen(false);
  };

  return (
    <Box>
      <IconButton
        aria-label="detection"
        color="primary"
        onClick={handleIconClick}
      >
        <VisibilityIcon />
      </IconButton>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Tracking Object</DialogTitle>
        <DialogContent sx={{ width: '400px' }}>
          <FormGroup>
            {Object.keys(selectedDetections).map((key) => (
              <FormControlLabel
                key={key}
                control={
                  <Checkbox
                    checked={selectedDetections[key]}
                    onChange={handleCheckboxChange}
                    name={key}
                  />
                }
                label={key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
              />
            ))}
          </FormGroup>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSave} color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
