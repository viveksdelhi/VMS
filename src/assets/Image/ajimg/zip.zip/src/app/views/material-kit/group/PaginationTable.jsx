import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  IconButton,
  Table,
  styled,
  TableRow,
  TableBody,
  TableCell, //bst
  TableHead,
  TablePagination,
  Switch,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import { API, token } from "serverConnection";

// STYLED COMPONENT
const StyledTable = styled(Table)(() => ({
  whiteSpace: "pre",
  "& thead": {
    "& tr": { "& th": { paddingLeft: 0, paddingRight: 0 } },
  },
  "& tbody": {
    "& tr": { "& td": { paddingLeft: 0, textTransform: "capitalize" } },
  },
}));

export default function PaginationTable() {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [subscribers, setSubscribers] = useState([]);
  const [newCategory, setNewCategory] = useState({
    name: "",
    description: "",
  });
  const [editIndex, setEditIndex] = useState(null);
  const [errors, setErrors] = useState({ name: false, description: false });
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState(null);

  // Fetch Data from API
  const getApiData = () => {
    axios
      .get(`${API}/api/Group/GetAll`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setSubscribers(
          response.data.map((subscriber) => ({
            ...subscriber,
            status: Boolean(subscriber.status), // Ensure status is a boolean
          }))
        );
      })
      .catch((error) => {
        console.error(
          "Error fetching data:",
          error.response?.data || error.message
        );
      });
  };

  useEffect(() => {
    getApiData();
  }, []);

  // Add or Edit Category
  const handleAddOrEditCategory = (event) => {
    event.preventDefault();

    if (!validateForm()) return;

    if (editIndex !== null) {
      handleEditCategory();
    } else {
      handleAddCategory();
    }
  };

  // Add a New Category
  const handleAddCategory = () => {
    axios
      .post(`${API}/api/Group`, newCategory, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setSubscribers([...subscribers, response.data]);
        setNewCategory({ name: "", description: "" });
      })
      .catch((error) => {
        console.error(
          "Error adding category:",
          error.response?.data || error.message
        );
      });
  };

  // Edit an Existing Category
  const handleEditCategory = () => {
    // const categoryToEdit = subscribers[editIndex];

    axios
      .put(
        `${API}/api/Group/`,
        newCategory,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      .then((response) => {
        const updatedSubscribers = subscribers.map((subscriber, i) =>
          i === editIndex ? response.data : subscriber
        );
        setSubscribers(updatedSubscribers);
        setNewCategory({ name: "", description: "" });
        setEditIndex(null);
        getApiData();
      })
      .catch((error) => {
        console.error(
          "Error updating category:",
          error.response?.data || error.message
        );
      });
  };

  // Validate Form
  const validateForm = () => {
    const newErrors = {
      name: newCategory.name === "",
      description: newCategory.description === "",
    };
    setErrors(newErrors);
    return !newErrors.name && !newErrors.description;
  };

  // Delete a Category
  const handleDeleteCategory = async () => {
    const categoryToDelete = subscribers[deleteIndex];
  
    try {
        await axios.delete(`${API}/api/Group/${categoryToDelete.id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      // On success, update the state and UI
      setSubscribers(subscribers.filter((_, i) => i !== deleteIndex));
      setOpenDeleteDialog(false);
      setDeleteIndex(null);
    } catch (error) {
      console.error(
        "Error deleting category:",
        error.response?.data || error.message
      );
    }
  };
  

  // Handle Page Change
  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  // Handle Rows Per Page Change
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

 // Toggle Status
const handleStatusToggle = (index) => {
  const subscriberToUpdate = subscribers[index];
  const updatedStatus = !subscriberToUpdate.status; // Toggle the status

  // Optimistically update local state
  const updatedSubscribers = subscribers.map((subscriber, i) =>
    i === index ? { ...subscriber, status: updatedStatus } : subscriber
  );
  setSubscribers(updatedSubscribers);

  // Prepare the payload with necessary fields like ID and status
  const payload = {
    id: subscriberToUpdate.id,
    status: updatedStatus,
  };

  // Send the status update to the API
  axios
    .put(
      `${API}/api/Group/update-status`,
      payload, // Send the proper payload to the API
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )
    .then(() => {
      console.log("Status updated successfully");
    })
    .catch((error) => {
      console.error(
        "Error updating status:",
        error.response?.data || error.message
      );
      // Revert local state on error
      setSubscribers(subscribers);
    });
};


  const handleEdit = (index, id) => {
    setEditIndex(index);
    const subscriberToEdit = subscribers[index];
    setNewCategory({
      name: subscriberToEdit.name,
      description: subscriberToEdit.description,
      id: id,
    });
  };

  const handleDeleteClick = (index) => {
    setDeleteIndex(index);
    setOpenDeleteDialog(true);
  };

  const handleDeleteCancel = () => {
    
    setOpenDeleteDialog(false);
    setDeleteIndex(null);
  };

  return (
    <Box width="100%" overflow="auto">
      <form onSubmit={handleAddOrEditCategory}>
        <Box display="flex" alignItems="center" mb={2} mt={1}>
          <TextField
            label="Name"
            variant="outlined"
            size="small"
            value={newCategory.name}
            onChange={(e) =>
              setNewCategory({ ...newCategory, name: e.target.value })
            }
            sx={{ mr: 2, width: "400px" }}
            error={errors.name}
            helperText={errors.name ? "Name is required" : ""}
            required
          />
          <TextField
            label="Description"
            variant="outlined"
            size="small"
            value={newCategory.description}
            onChange={(e) =>
              setNewCategory({ ...newCategory, description: e.target.value })
            }
            sx={{ mr: 2, width: "400px" }}
            error={errors.description}
            helperText={errors.description ? "Description is required" : ""}
            required
          />
          <Button variant="contained" color="primary" type="submit">
            {editIndex !== null ? "Edit Category" : "Add Category"}
          </Button>
        </Box>
      </form>

      <StyledTable>
        <TableHead>
          <TableRow>
            <TableCell align="left">ID</TableCell>
            <TableCell align="left">Name</TableCell>
            <TableCell align="left">Description</TableCell>
            <TableCell align="center">Status</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {subscribers
            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
            .map((subscriber, index) => (
              <TableRow key={subscriber.id}>
                <TableCell align="left">{index+1}</TableCell>
                <TableCell align="left">{subscriber.name}</TableCell>
                <TableCell align="left">{subscriber.description}</TableCell>
                <TableCell align="center">
                  <Switch
                    checked={subscriber.status}
                    onChange={() =>
                      handleStatusToggle(page * rowsPerPage + index, subscriber.status)
                    }
                  />
                </TableCell>
                <TableCell align="right">
                  <IconButton
                    onClick={() =>
                      handleEdit(page * rowsPerPage + index, subscriber.id)
                    }
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton
                    onClick={() =>
                      handleDeleteClick(page * rowsPerPage + index)
                    }
                  >
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
        </TableBody>
      </StyledTable>

      <TablePagination
        sx={{ px: 2 }}
        page={page}
        component="div"
        rowsPerPage={rowsPerPage}
        count={subscribers.length}
        rowsPerPageOptions={[5, 10, 25]}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleChangeRowsPerPage}
        nextIconButtonProps={{ "aria-label": "Next Page" }}
        backIconButtonProps={{ "aria-label": "Previous Page" }}
      />

      <Dialog open={openDeleteDialog} onClose={handleDeleteCancel}>
        <DialogTitle>
          {"Are you sure you want to delete this category?"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>This action cannot be undone.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDeleteCategory} color="secondary" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
