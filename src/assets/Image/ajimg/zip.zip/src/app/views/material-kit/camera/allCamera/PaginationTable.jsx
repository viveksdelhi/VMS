import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  IconButton,
  Table,
  styled,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  Switch,
  TextField,
  InputAdornment,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import FileDownloadIcon from "@mui/icons-material/FileDownload";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import DescriptionIcon from "@mui/icons-material/Description";
import SearchIcon from "@mui/icons-material/Search";
import axios from "axios";
import { API, token } from "serverConnection";
import * as XLSX from "xlsx";
import { Document, Packer, Paragraph, TextRun } from "docx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import "jspdf-autotable";
import moment from "moment";
import { ObjectDetection } from "../../object/ObjectDetection";
import { useNavigate } from 'react-router-dom';
// STYLED COMPONENT
const StyledTable = styled(Table)(() => ({
  whiteSpace: "pre",
  "& thead": {
    "& tr": { "& th": { paddingLeft: 0, paddingRight: 0 } },
  },
  "& tbody": {
    "& tr": { "& td": { paddingLeft: 0, textTransform: "capitalize" } },
  },
}));

export default function CameraList() {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [cameras, setCameras] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false); // State for delete dialog
  const [currentCamera, setCurrentCamera] = useState(null);
  const [formValues, setFormValues] = useState({
    name: "",
    cameraIP: "",
    location: "",
    port: "",
    channelId: "",
    nvrId: "",
    groupId: "",
    rtspurl: "",
    latitude: "",
    longitude: "",
    lastLive: "",
  });
  useEffect(() => {
    fetchCameras();
  }, []);

  const navigate = useNavigate();

  const handleClick = () => {
    // Replace '/target-path' with the path you want to navigate to
    navigate('/add-camera');
  };

  useEffect(() => {
    // Dynamic search filtering
    const filtered = cameras.filter(
      (camera) =>
        camera.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        camera.cameraIP.toLowerCase().includes(searchQuery.toLowerCase()) ||
        camera.groupId.toString().includes(searchQuery.toString()) ||
        camera.location.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSearchResults(filtered);
    setPage(0);
  }, [searchQuery, cameras]);

  const fetchCameras = async () => {
    try {
      const response = await axios.get(`${API}/api/Camera/GetAll`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCameras(response.data);
      setSearchResults(response.data);
    } catch (error) {
      console.error("Error fetching cameras:", error);
    }
  };

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const handleStatusToggle = (index) => {
    const cameraToUpdate = cameras[index];
    const updatedStatus = !cameraToUpdate.status; // Toggle the status

    // Optimistically update local state
    const updatedSubscribers = cameras.map((subscriber, i) =>
      i === index ? { ...subscriber, status: updatedStatus } : subscriber
    );
    setCameras(updatedSubscribers);

    // Prepare the payload with necessary fields like ID and status
    const payload = {
      id: cameraToUpdate.id,
      status: updatedStatus,
    };

    // Send the status update to the API
    axios
      .put(
        `${API}/api/Camera/update-status`,
        payload, // Send the proper payload to the API
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      .then(() => {
        console.log("Status updated successfully");
        fetchCameras();
      })
      .catch((error) => {
        console.error(
          "Error updating status:",
          error.response?.data || error.message
        );
        // Revert local state on error
        setCameras(cameras);
      });
  };

  const handleDeleteClick = (camera) => {
    setCurrentCamera(camera);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (currentCamera) {
      try {
        await axios.delete(`${API}/api/Camera/${currentCamera.id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setCameras((prevCameras) =>
          prevCameras.filter((cam) => cam.id !== currentCamera.id)
        );
        setSearchResults((prevSearchResults) =>
          prevSearchResults.filter((cam) => cam.id !== currentCamera.id)
        );
        setDeleteDialogOpen(false);
      } catch (error) {
        console.error("Error deleting camera:", error);
      }
    }
  };

  const handleEditClick = (camera) => {
    setCurrentCamera(camera);
    setFormValues({
      name: camera.name,
      cameraIP: camera.cameraIP,
      location: camera.location,
      port: camera.port,
      channelId: camera.channelId,
      nvrId: camera.nvrId,
      groupId: camera.groupId,
      rtspurl: camera.rtspurl,
      latitude: camera.latitude,
      longitude: camera.longitude,
      status: camera.status,
      lastLive: camera.lastLive,
    });
    setEditDialogOpen(true);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const handleFormSubmit = async () => {
    if (currentCamera) {
      try {
        const updatedCamera = {
          ...formValues,
          id: currentCamera.id,
          lastLive: new Date().toISOString(),
        };

        await axios.put(`${API}/api/Camera`, updatedCamera, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log("Updated camera:", updatedCamera);

        setCameras((prevCameras) =>
          prevCameras.map((cam) =>
            cam.id === currentCamera.id ? updatedCamera : cam
          )
        );
        setSearchResults((prevSearchResults) =>
          prevSearchResults.map((cam) =>
            cam.id === currentCamera.id ? updatedCamera : cam
          )
        );
        setEditDialogOpen(false);
      } catch (error) {
        console.error("Error updating camera:", error);
      }
    }
  };

  const downloadAsExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(searchResults);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Cameras");
    XLSX.writeFile(workbook, "cameras.xlsx");
  };

  const downloadAsDocs = async () => {
    const doc = new Document({
      sections: [
        {
          children: searchResults.map(
            (camera) =>
              new Paragraph({
                children: [
                  new TextRun(
                    `Name: ${camera.name}, Camera IP: ${camera.cameraIP}, Group ID: ${camera.groupId}, Last Live: ${camera.lastLive}, Location: ${camera.location}, Status: ${camera.status}`
                  ),
                ],
              })
          ),
        },
      ],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "cameras.docx");
  };

  const downloadAsPDF = () => {
    const doc = new jsPDF();
    doc.text("Camera List", 14, 16);

    const tableColumn = [
      "S.No.",
      "Name",
      "Camera IP",
      "Group ID",
      "Last Live",
      "Location",
      "Status",
    ];
    const tableRows = searchResults.map((camera) => [
      camera.id,
      camera.name,
      camera.cameraIP,
      camera.groupId,
      camera.lastLive,
      camera.location,
      camera.status,
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save("cameras.pdf");
  };

  return (
    <Box width="100%" overflow="auto">
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mt={2}
        mb={2}
      >
        <Box display="flex" alignItems="center">
          <TextField
            variant="outlined"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            sx={{ width: "100%" }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              ml: 60,
            }}
          >
            <Button
              variant="contained"
              color="primary"
              sx={{ ml: 1 }}
              onClick={handleClick}
            >
              +
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={downloadAsExcel}
              sx={{ ml: 1 }}
            >
              <FileDownloadIcon /> Excel
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={downloadAsDocs}
              sx={{ ml: 1 }}
            >
              <DescriptionIcon /> Docs
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={downloadAsPDF}
              sx={{ ml: 1 }}
            >
              <PictureAsPdfIcon /> PDF
            </Button>
          </Box>
        </Box>
      </Box>

      <StyledTable>
        <TableHead>
          <TableRow>
            <TableCell>S.No.</TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Camera IP</TableCell>
            <TableCell>Group ID</TableCell>
            <TableCell>Last Live</TableCell>
            <TableCell>Location</TableCell>
            <TableCell>Object Detection</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {searchResults
            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
            .map((camera, index) => (
              <TableRow key={camera.id}>
                <TableCell>{camera.id}</TableCell>
                <TableCell>{camera.name}</TableCell>
                <TableCell>{camera.cameraIP}</TableCell>
                <TableCell>{camera.groupId}</TableCell>
                <TableCell sx={{ textAlign: "center" }}>
                  {camera.lastLive
                    ? moment(camera.lastLive).isValid()
                      ? moment(camera.lastLive).format("YYYY-MM-DD HH:mm")
                      : "Invalid Date"
                    : "No Data Available"}
                </TableCell>
                <TableCell>{camera.location}</TableCell>

                <TableCell sx={{ textAlign: "center" }}>
                  <ObjectDetection />
                </TableCell>

                <TableCell>
                  <Switch
                    checked={camera.status}
                    onChange={() => handleStatusToggle(index)}
                  />
                </TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEditClick(camera)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDeleteClick(camera)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow> 
            ))}
        </TableBody>
      </StyledTable>

      <TablePagination
        rowsPerPageOptions={[25, 50, 100]}
        component="div"
        count={searchResults.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />

      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)}>
        <DialogTitle>Edit Camera</DialogTitle>
        <DialogContent>
          <TextField
            label="Name"
            name="name"
            value={formValues.name}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Camera IP"
            name="cameraIP"
            value={formValues.cameraIP}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Location"
            name="location"
            value={formValues.location}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Port"
            name="port"
            value={formValues.port}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Channel ID"
            name="channelId"
            value={formValues.channelId}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="NVR ID"
            name="nvrId"
            value={formValues.nvrId}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Group ID"
            name="groupId"
            value={formValues.groupId}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="RTSP URL"
            name="rtspurl"
            value={formValues.rtspurl}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Latitude"
            name="latitude"
            value={formValues.latitude}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Longitude"
            name="longitude"
            value={formValues.longitude}
            onChange={handleFormChange}
            fullWidth
            margin="dense"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleFormSubmit}>Save</Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete this camera?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleConfirmDelete}>Delete</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
