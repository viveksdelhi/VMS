export const API = "http://122.176.105.30:9120";
export const StreamAPI = "http://122.176.105.30:9121";
export const RTSPAPI = "http://122.176.105.30:9122/live";
export const VideoAPI = "http://122.176.105.30:9122/RTSPSavedVideo";
export const token  = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjc1ODkyNDIsImlzcyI6ImFkbWluIiwiYXVkIjoiYWRtaW4ifQ.mlJcWmbwE04kNjKcU0ZDcBC97uTqqPbRP0UeZFdLgBE"
export const ANPRAPI = "http://122.176.105.30:9100";


// export const API = "https://ajeevivmsapi.mikrowsoft.com";
// export const StreamAPI = "https://ajeevistream.mikrowsoft.com";
// export const RTSPAPI = "https://ajeevirtsp.mikrowsoft.com/live";
// export const VideoAPI = "https://ajeevirtsp.mikrowsoft.com/RTSPSavedVideo";
// export const token  = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjc1ODkyNDIsImlzcyI6ImFkbWluIiwiYXVkIjoiYWRtaW4ifQ.mlJcWmbwE04kNjKcU0ZDcBC97uTqqPbRP0UeZFdLgBE"
// export const ANPRAPI = "https://ajeevianpr.mikrowsoft.com";