import React, { useState, useEffect, useRef } from 'react';
import { Container, Row, Col, Dropdown, DropdownButton, Button } from 'react-bootstrap';
import Hls from 'hls.js';
import axios from 'axios';
import { API, RTSPAPI, StreamAPI, token } from 'serverConnection';
import { ObjectDetection } from '../object/ObjectDetection';
import { FaExpand, FaRecordVinyl, FaPause,FaMapMarkerAlt } from 'react-icons/fa';

const VideoGrid = () => {
  const [gridSize, setGridSize] = useState(2);
  const [videoUrls, setVideoUrls] = useState([]);
  const [cameraData, setCameraData] = useState([]);
  const [isRecording, setIsRecording] = useState({}); // Track recording state for each camera

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${API}/api/Camera/CMR`, {
          headers: { "Authorization": `Bearer ${token}` }
        });

        const data = response.data;
        const updatedUrls = data.map(camera => `${RTSPAPI}/${camera.id}/index.m3u8`);

        const postRequests = data.map(camera =>
          axios.post(`${StreamAPI}/api/Video/start-stream-new`, {
            id: camera.id,
            name: camera.name,
            rtspUrl: camera.rtspurl[0]
          })
        );
        await Promise.all(postRequests);

        // Set initial recording state to false (off by default)
        const initialRecordingState = data.reduce((acc, camera) => {
          acc[camera.id] = false; // Default recording off
          return acc;
        }, {});

        setCameraData(data);
        setVideoUrls(updatedUrls);
        setIsRecording(initialRecordingState);
      } catch (error) {
        console.error("Error fetching or posting data:", error);
      }
    };

    fetchData();
  }, []);

  const handleSelect = (eventKey) => setGridSize(Number(eventKey));

  const renderGrid = () => {
    const rows = [];

    for (let i = 0; i < gridSize; i++) {
      const cols = [];
      for (let j = 0; j < gridSize; j++) {
        const videoIndex = i * gridSize + j;

        if (videoIndex < videoUrls.length) {
          const url = videoUrls[videoIndex];
          const camera = cameraData[videoIndex];

          cols.push(
            <Col key={j} className='p-0 m-0 border border-warning bg-dark'>
              <VideoPlayer
                key={videoIndex}
                url={url}
                camera={camera}
                isRecording={isRecording[camera.id]}
                toggleRecording={() => toggleRecording(camera.id)}
              />
            </Col>
          );
        } else {
          cols.push(
            <Col key={j} className='p-0 m-0'>
              <div className="p-0 m-0" style={{ width: '100%', height: 'auto', backgroundColor: '#f0f0f0' }}></div>
            </Col>
          );
        }
      }
      rows.push(<Row className='p-0 m-0' key={i}>{cols}</Row>);
    }
    return rows;
  };

  const toggleRecording = async (cameraId) => {
    try {
      const currentState = isRecording[cameraId];
      const newState = !currentState;
      // Toggle the recording state
      setIsRecording(prevState => ({ ...prevState, [cameraId]: newState }));
    
      const endpoint = newState
        ? `${StreamAPI}/api/Video/start-stream-new`
        : `${StreamAPI}/api/Video/stop-stream`;

      await axios.post(endpoint, {
        id: cameraId,
        name: cameraData.find(camera => camera.id === cameraId).name,
      });
    } catch (error) {
      console.error("Error toggling recording:", error);
    }
  };

  return (
    <Container className='bg-dark' style={{ maxWidth: "100%" }}>
      <DropdownButton
        id="dropdown-basic-button"
        title={`Grid: ${gridSize}x${gridSize}`}
        onSelect={handleSelect}
        className="mb-3"
      >
        <Dropdown.Item eventKey="2">2x2</Dropdown.Item>
        <Dropdown.Item eventKey="3">3x3</Dropdown.Item>
        <Dropdown.Item eventKey="4">4x4</Dropdown.Item>
        <Dropdown.Item eventKey="5">5x5</Dropdown.Item>
        <Dropdown.Item eventKey="6">6x6</Dropdown.Item>
        <Dropdown.Item eventKey="7">7x7</Dropdown.Item>
        <Dropdown.Item eventKey="8">8x8</Dropdown.Item>
      </DropdownButton>

      {renderGrid()}
    </Container>
  );
};

const VideoPlayer = ({ url, camera, isRecording, toggleRecording }) => {
  const videoRef = useRef(null);

  const handleFullScreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      } else if (videoRef.current.mozRequestFullScreen) { // Firefox
        videoRef.current.mozRequestFullScreen();
      } else if (videoRef.current.webkitRequestFullscreen) { // Chrome, Safari, and Opera
        videoRef.current.webkitRequestFullscreen();
      } else if (videoRef.current.msRequestFullscreen) { // IE/Edge
        videoRef.current.msRequestFullscreen();
      }
    }
  };

  useEffect(() => {
    const videoElement = videoRef.current;

    if (Hls.isSupported() && videoElement) {
      const hls = new Hls();

      hls.loadSource(url);
      hls.attachMedia(videoElement);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        videoElement.muted = true;
      });

      return () => {
        hls.destroy();
      };
    } else if (videoElement) {
      videoElement.src = url;
      videoElement.muted = true;
      videoElement.play().catch(error => {
        console.error('Error attempting to play:', error);
      });
    }
  }, [url]);

  return (
    <div style={{ position: 'relative', display: 'inline-block', width: '100%', height: '100%' }}>
      <video
        ref={videoRef}
        className="p-0 m-0"
        preload="auto"
        width="100%"
        height="300px"
        autoPlay
      />
        <div style={{ color:"white", display: "inline",position:"relative",float:"left",padding:"10px" }}>
          {camera.id}-{camera.name}
        </div>
      <div style={{ position: 'relative',float:"right",display:"flex",alignItems:"center" }}>
      <FaMapMarkerAlt
          style={{ color: "skyblue", cursor: "pointer", marginLeft: '10px',fontSize:'20px' }}
          onClick={() => {
            // Implement location feature functionality here
            alert('Location icon clicked');
          }}
        />
        <ObjectDetection />
        <FaExpand
          style={{ color: "white", cursor: "pointer" }}
          onClick={(e) => {
            e.stopPropagation();
            handleFullScreen();
          }}
        />
       <Button
  variant={isRecording ? "danger" : "primary"}
  onClick={(e) => {
    e.stopPropagation();
    toggleRecording(camera.id);
    alert('Camera Recording is on')  // Pass the cameraId to toggleRecording
  }}
  style={{ marginLeft: '10px', padding: '5px 10px', marginRight: '5px' }}
>
  {isRecording ? <FaPause /> : <FaRecordVinyl />}
</Button>    
      </div>
    </div>
  );
};

export default VideoGrid;
