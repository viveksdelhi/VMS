import React, { useState, useEffect } from "react";
import axios from "axios";
import { Card, ListGroup, Table, Modal, Button } from "react-bootstrap";
import Hls from "hls.js";
import { PlayCircleOutline, StopCircle, PhotoCamera } from "@mui/icons-material";
import IconButton from "@mui/material/IconButton";
import { API, RTSPAPI, token } from "serverConnection";
function Anpr() {//
  const [cameraList, setCameraList] = useState([]);
  const [selectedCamera, setSelectedCamera] = useState(null);
  const [videoUrl, setVideoUrl] = useState("");
  const [tableData, setTableData] = useState([]);
  const [showImageModal, setShowImageModal] = useState(false);
  const [modalImageUrl, setModalImageUrl] = useState("");
  //video play/pause
  const [videoPlaying, setVideoPlaying] = useState(false);

  useEffect(() => {
    const fetchCameras = async () => {
      try {
        const response = await axios.get(`${API}/api/Camera/CMR`);
        const cameras = response.data;
        setCameraList(cameras);

        if (cameras.length > 0) {
          handleCameraClick(cameras[0]); // Automatically select and play the first camera
        }
      } catch (error) {
        console.error("Error fetching camera list:", error);
      }
    };

    const fetchAllCameraData = async () => {
      try {
        const response = await axios.get(`${API}/api/CameraTrackingData/GetAll`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setTableData(response.data); // Display all camera data by default
      } catch (error) {
        console.error("Error fetching camera data:", error);
      }
    };

    fetchCameras();
    fetchAllCameraData(); // Fetch all camera data on initial load
  }, []);

  useEffect(() => {
    if (videoUrl && Hls.isSupported()) {
      const videoElement = document.getElementById("camera-video");
      const hls = new Hls();
      hls.loadSource(videoUrl);
      hls.attachMedia(videoElement);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        videoElement
          .play()
          .catch((error) => console.error("Error attempting to play", error));
      });

      return () => {
        hls.destroy();
      };
    } else if (videoUrl) {
      const videoElement = document.getElementById("camera-video");
      videoElement.src = videoUrl;
      videoElement.addEventListener("loadedmetadata", () => {
        videoElement
          .play()
          .catch((error) => console.error("Error attempting to play", error));
      });

      return () => {
        videoElement.removeEventListener("loadedmetadata", () => {});
      };
    }
  }, [videoUrl]);

  
  const handleCameraClick = async (camera) => {
    setSelectedCamera(camera);
  
    try {
      const response = await axios.get(`${API}/api/CameraTrackingData/GetAll`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const allCameraData = response.data;
  
      const filteredCameraData = allCameraData.filter(
        (data) => data.cameraId === camera.id
      );
  
      setTableData(filteredCameraData.length > 0 ? filteredCameraData : []);
    } catch (error) {
      console.error("Error fetching camera data:", error);
    }
  
    if (camera === selectedCamera) {
      // Toggle video if the same camera is selected
      handleVideoToggle();
    } else {
      // Start or switch video feed
      setVideoUrl(`${RTSPAPI}/${camera.id}/index.m3u8`);
      setVideoPlaying(true);
    }
  };
  

  const handleVideoToggle = () => {
    const videoElement = document.getElementById("camera-video");
  
    if (videoPlaying) {
      // Pause the video
      videoElement.pause();
      setVideoPlaying(false);
    } else {
      // Play the video
      videoElement.play();
      setVideoPlaying(true);
    }
  };
  


  const handleImageClick = (imageUrl) => {
    setModalImageUrl(imageUrl);
    setShowImageModal(true);
  };

  const handleCloseModal = () => setShowImageModal(false);

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-md-3 col-3">
          <Card
            className="shadow-sm bg-dark text-light"
            style={{ height: "220px" }}
          >
            <Card.Header className="text-center" as="h5">
              Camera
            </Card.Header>
            <Card.Body
              className="p-0 bg-dark text-light"
              style={{
                height: "300px",
                overflowY: "auto",
                msOverflowStyle: "none",
                scrollbarWidth: "none",
              }}
            >
              <ListGroup className="bg-dark text-light">
                {cameraList.map((camera) => (
                  <ListGroup.Item
                    key={camera.id}
                    className="bg-dark text-light d-flex justify-content-between align-items-center"
                    style={{ border: "none", padding: "0px 10px" }}
                  >
                    <span style={{ fontSize: "14px" }}>{camera.name}</span>
                    <IconButton
                      onClick={() => handleCameraClick(camera)}
                      color="primary"
                      className="ms-2"
                      size="small"
                    >
                      {selectedCamera === camera && videoPlaying ? (
                        <StopCircle/>
                      ) : (
                        <PlayCircleOutline />
                      )}
                    </IconButton>
                  </ListGroup.Item>
                ))}
              </ListGroup>
            </Card.Body>
          </Card>
        </div>

        <div className="col-md-6 col-6">
          <Card
            className="shadow-sm bg-dark m-0 p-0"
            style={{ height: "220px" }}
          >
            <Card.Header className="text-light text-center" as="h5">
              Event & Object Detection
            </Card.Header>
            <Card.Body
              className="text-center m-0 p-0"
              style={{ height: "300px", padding: 0 }}
            >
              {selectedCamera ? (
                <div style={{ width: "100%", height: "100%" }}>
                  <video
                    id="camera-video"
                    controls
                    autoPlay
                    muted
                    style={{
                      width: "100%",
                      height: "175px",
                      borderRadius: "5px",
                    }}
                  />
                </div>
              ) : (
                <p className="text-danger">Select a camera to view the feed</p>
              )}
            </Card.Body>
          </Card>
        </div>

        <div className="col-md-3 col-3">
          <Card className="shadow-sm bg-dark" style={{ height: "220px" }}>
            <Card.Header className="text-light text-center" as="h5">
              Vehicle Details
            </Card.Header>
            <Card.Body
              style={{
                height: "300px",
                overflowY: "auto",
                msOverflowStyle: "none", // IE and Edge
                scrollbarWidth: "none", // Firefox
                padding: "0 1rem", // Add some padding to the content
              }}
            >
              {selectedCamera && tableData.length > 0 ? (
                <div>
                  <img
                    src={`http://122.176.158.202:9123/${tableData[0].vichelImage}`}
                    alt="Vehicle"
                    className="img-fluid"
                    style={{ borderRadius: "5px" }}
                  />
                  <img
                    src={`http://122.176.158.202:9123/${tableData[0].noPlateImage}`}
                    alt="Vehicle"
                    className="img-fluid"
                    style={{ borderRadius: "5px" }}
                  />
                </div>
              ) : (
                <p className="text-danger">Select a camera to view details</p>
              )}
            </Card.Body>
          </Card>
        </div>
      </div>

      {/* Table below AllCamera */}
      <div className="mt-4">
        <Table striped bordered hover variant="dark">
          <thead>
            <tr>
              <th>S.No.</th>
              <th>Camera Name</th>
              <th>Vehicle Image</th>
              <th>No. Plate Image</th>
              <th>Vehicle No</th>
              <th>Date and Time</th>
            </tr>
          </thead>
          <tbody>
            {tableData.map((data, index) => (
              <tr key={data.id}>
                <td>{index + 1}</td>
                <td>{data.camera.name}</td>
                <td className="text-center">
                  <IconButton
                    onClick={() =>
                      handleImageClick(
                        `http://122.176.158.202:9123/${data.vichelImage}`
                      )
                    }
                    color="primary"
                    className="ms-2"
                    size="small"
                  >
                    <PhotoCamera />
                  </IconButton>
                </td>
                <td className="text-center">
                  <IconButton
                    onClick={() =>
                      handleImageClick(
                        `http://122.176.158.202:9123/${data.noPlateImage}`
                      )
                    }
                    color="primary"
                    className="ms-2"
                    size="small"
                  >
                    <PhotoCamera />
                  </IconButton>
                </td>
                <td>{data.vichelNo}</td>
                <td>{data.regDate}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>

      {/* Modal for Viewing Images */}
      <Modal show={showImageModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Vehicle Image</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <img
            src={modalImageUrl}
            alt="Vehicle"
            className="img-fluid"
            style={{ width: "100%" }}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default Anpr;
