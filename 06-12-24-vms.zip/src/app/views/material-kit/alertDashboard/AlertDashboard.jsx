import React from 'react'

function AlertDashboard() {
  return (
    <div>AlertDashboard</div>
  )
}

export default AlertDashboard